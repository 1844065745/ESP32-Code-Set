#ifndef MYTIMER_H_
#define MYTIMER_H_

#include <Arduino.h>


void timer_init(void);
void IRAM_ATTR TimerEvent(void);



#endif
